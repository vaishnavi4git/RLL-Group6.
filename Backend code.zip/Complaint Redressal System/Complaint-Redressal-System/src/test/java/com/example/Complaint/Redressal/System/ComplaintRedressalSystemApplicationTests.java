package com.example.Complaint.Redressal.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintRedressalSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
