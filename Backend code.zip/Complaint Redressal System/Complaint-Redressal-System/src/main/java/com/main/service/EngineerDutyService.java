package com.main.service;

import com.main.model.EngineerDuty;

public interface EngineerDutyService {
	void saveEngineerDuty (EngineerDuty engineerDuty);

}